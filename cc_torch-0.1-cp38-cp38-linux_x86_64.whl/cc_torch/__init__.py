from .connected_components import connected_components_labeling

__all__ = ["connected_components_labeling"]
